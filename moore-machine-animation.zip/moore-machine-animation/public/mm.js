const states = document.querySelectorAll('.state');
const arrows = document.querySelectorAll('.arrow');
const outputElement = document.getElementById('output');

const mooreMachine = {
    currentState: 0,
    states: [
        { output: 0, next: [0, 0] }, 

        { output: 1, next: [1, 1] }     ],
    transition(input) {
        const state = this.states[this.currentState];

        // Determine next state 0 for 'b', 1 for 'a'
        const nextState = input === 'a' ? 1 : 0;

        // Hide all arrows first
        arrows.forEach(arrow => {
            arrow.style.display = 'none';
        });

        // Get the arrow to be displayed
        const arrowElement = document.querySelector(`#arrow${this.currentState}${nextState}`);
        if (arrowElement) {
            arrowElement.style.display = 'block';
        } else {
            console.error(`Arrow element with ID arrow${this.currentState}${nextState} not found.`);
        }

        // Update the current state
        this.currentState = nextState;

        // Update output display
        outputElement.textContent += this.states[this.currentState].output;
    }
};

let inputSequence = ['a', 'b', 'b', 'a']; 
let currentIndex = 0;

function startMachine() {
    outputElement.textContent = ''; // Clear previous output
    currentIndex = 0; // Reset the sequence

    // Include the initial state output before any transitions
    outputElement.textContent += mooreMachine.states[mooreMachine.currentState].output;

    function animate() {
        if (currentIndex < inputSequence.length) {
            const input = inputSequence[currentIndex];
            mooreMachine.transition(input);

            // Update state colors
            states.forEach((state, index) => {
                state.style.backgroundColor = (index === mooreMachine.currentState) ? '#e74c3c' : '#3498db';
            });

            // Move to the next input
            currentIndex++;

            // Continue the animation until the sequence ends
            if (currentIndex < inputSequence.length) {
                setTimeout(animate, 1000);
            }
        }
    }

    animate();
}
